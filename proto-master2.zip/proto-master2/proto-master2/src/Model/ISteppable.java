package Model;

/**
 * Egy léptethető dolog.
 */
public interface ISteppable {

    /**
     * Lépteti a dolgot egyszer.
     */
    void Step();
}
