package Model;

/**
 * Szabotőr játékos
 * A játékos képességein felül képes csövet lyukasztani.
 */
public class Saboteur extends Player{
    /**
     * Konstruktor
     */
    public Saboteur() {
        Skeleton.CtorStart("Saboteur()");
        Skeleton.End();
    }
}
